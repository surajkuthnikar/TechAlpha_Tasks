//write a java program to find a missing number in an array.

public class Missing_Number {

    public static void main(String[] args) {
        int[] array = { 1, 2, 3, 5, 6 };

        int missingNumber = findMissingNumber(array);

        System.out.println("Original Array:");
        printArray(array);

        System.out.println("Missing Number: " + missingNumber);
    }

    public static int findMissingNumber(int[] array) {
        int n = array.length + 1;
        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;

        for (int num : array) {
            actualSum += num;
        }

        return expectedSum - actualSum;
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
