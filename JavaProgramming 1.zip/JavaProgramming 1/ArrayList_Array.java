
//write a java program to convert an Arraylist into an array.
import java.util.ArrayList;

public class ArrayList_Array {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Cherry");
        arrayList.add("Date");
        arrayList.add("Elderberry");

        String[] array = arrayListToArray(arrayList);

        System.out.println("ArrayList:");
        printArrayList(arrayList);

        System.out.println("Array:");
        printArray(array);
    }

    public static String[] arrayListToArray(ArrayList<String> arrayList) {
        String[] array = new String[arrayList.size()];
        return arrayList.toArray(array);
    }

    public static void printArrayList(ArrayList<String> arrayList) {
        for (String element : arrayList) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public static void printArray(String[] array) {
        for (String element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
