import java.util.ArrayList;
import java.util.List;

public class AirlineReservationSystem {
    private List<Flight> flights;
    private List<Booking> bookings;

    public AirlineReservationSystem() {
        this.flights = new ArrayList<>();
        this.bookings = new ArrayList<>();
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
    }

    public void makeBooking(Flight flight, Passenger passenger) {
        Booking booking = new Booking(flight, passenger);
        bookings.add(booking);
    }

    public void confirmBooking(Booking booking) {
        booking.confirmBooking();
    }

    public void displayBookings() {
        for (Booking booking : bookings) {
            System.out.println("Flight " + booking.getFlight().getFlightNumber() + " from "
                    + booking.getFlight().getOrigin() + " to " + booking.getFlight().getDestination());
            System.out.println("Passenger: " + booking.getPassenger().getName());
            System.out.println("Contact Information: " + booking.getPassenger().getContactInformation());
            System.out.println("Booking Status: " + (booking.isConfirmed() ? "Confirmed" : "Pending"));
            System.out.println();
        }
    }

    public static void main(String[] args) {
        AirlineReservationSystem system = new AirlineReservationSystem();

        Flight flight1 = new Flight(101, "New York", "Los Angeles", 200);
        Flight flight2 = new Flight(102, "Chicago", "San Francisco", 150);

        system.addFlight(flight1);
        system.addFlight(flight2);

        Passenger passenger1 = new Passenger("John Doe", "john.doe@example.com");
        Passenger passenger2 = new Passenger("Jane Smith", "jane.smith@example.com");

        system.makeBooking(flight1, passenger1);
        system.makeBooking(flight2, passenger2);

        system.confirmBooking(system.bookings.get(0));

        system.displayBookings();
    }
}