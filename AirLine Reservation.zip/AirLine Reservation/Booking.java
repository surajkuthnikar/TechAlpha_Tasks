public class Booking {

    private Flight flight;
    private Passenger passenger;
    private boolean isConfirmed;

    public Booking(Flight flight, Passenger passenger) {
        this.flight = flight;
        this.passenger = passenger;
        this.isConfirmed = false;
    }

    public Flight getFlight() {
        return flight;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public boolean isConfirmed() {
        return isConfirmed;
    }

    public void confirmBooking() {
        isConfirmed = true;
    }
}
